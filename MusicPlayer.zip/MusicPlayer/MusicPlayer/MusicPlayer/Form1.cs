namespace MusicPlayer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "MP3 Files|*.mp3|All Files|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                wmp.URL = ofd.FileName;
                lblCurrentSong.Text = "Playing: " + System.IO.Path.GetFileName(ofd.FileName);
            }
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            wmp.Ctlcontrols.play();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            wmp.Ctlcontrols.pause();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            wmp.Ctlcontrols.stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
