﻿namespace MusicPlayer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btnPlay = new Button();
            btnPause = new Button();
            btnStop = new Button();
            btnSelectFile = new Button();
            lblCurrentSong = new Label();
            wmp = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)wmp).BeginInit();
            SuspendLayout();
            // 
            // btnPlay
            // 
            btnPlay.Location = new Point(28, 65);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(94, 29);
            btnPlay.TabIndex = 0;
            btnPlay.Text = "Oynat";
            btnPlay.UseVisualStyleBackColor = true;
            btnPlay.Click += btnPlay_Click;
            // 
            // btnPause
            // 
            btnPause.Location = new Point(28, 100);
            btnPause.Name = "btnPause";
            btnPause.Size = new Size(94, 29);
            btnPause.TabIndex = 1;
            btnPause.Text = "Durdur";
            btnPause.UseVisualStyleBackColor = true;
            btnPause.Click += btnPause_Click;
            // 
            // btnStop
            // 
            btnStop.Location = new Point(28, 135);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(94, 29);
            btnStop.TabIndex = 2;
            btnStop.Text = "Bitir";
            btnStop.UseVisualStyleBackColor = true;
            btnStop.Click += btnStop_Click;
            // 
            // btnSelectFile
            // 
            btnSelectFile.Location = new Point(28, 30);
            btnSelectFile.Name = "btnSelectFile";
            btnSelectFile.Size = new Size(94, 29);
            btnSelectFile.TabIndex = 3;
            btnSelectFile.Text = "Dosya Seç";
            btnSelectFile.UseVisualStyleBackColor = true;
            btnSelectFile.Click += btnSelectFile_Click;
            // 
            // lblCurrentSong
            // 
            lblCurrentSong.AutoSize = true;
            lblCurrentSong.Location = new Point(28, 244);
            lblCurrentSong.Name = "lblCurrentSong";
            lblCurrentSong.Size = new Size(82, 20);
            lblCurrentSong.TabIndex = 4;
            lblCurrentSong.Text = "Çalan Şarkı";
            // 
            // wmp
            // 
            wmp.Enabled = true;
            wmp.Location = new Point(173, 30);
            wmp.Name = "wmp";
            wmp.OcxState = (AxHost.State)resources.GetObject("wmp.OcxState");
            wmp.Size = new Size(277, 185);
            wmp.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            ClientSize = new Size(502, 303);
            Controls.Add(wmp);
            Controls.Add(lblCurrentSong);
            Controls.Add(btnSelectFile);
            Controls.Add(btnStop);
            Controls.Add(btnPause);
            Controls.Add(btnPlay);
            Name = "Form1";
            Text = "Müzik Çalar";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)wmp).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPlay;
        private Button btnPause;
        private Button btnStop;
        private Button btnSelectFile;
        private Label lblCurrentSong;
        private AxWMPLib.AxWindowsMediaPlayer wmp;
    }
}
